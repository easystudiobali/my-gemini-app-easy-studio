
export enum BusinessUnit {
  PHOTO_STUDIO = 'PHOTO_STUDIO',
  PLAYSTATION = 'PLAYSTATION',
  HOWELL = 'HOWELL',
  ANALLS = 'ANALLS'
}

export interface Package {
  id: string;
  name: string;
  price: number;
  description: string;
  maxPeople: number;
  duration: number;
  unit: BusinessUnit;
}

export type BookingStatus = 'PENDING' | 'CONFIRMED' | 'CANCELLED' | 'PHOTO_TAKEN' | 'RESCHEDULED';

export interface Booking {
  id: string;
  customerName: string;
  customerPhone: string;
  customerInstagram?: string;
  date: string;
  time: string;
  packageId: string;
  unit: BusinessUnit;
  status: BookingStatus;
  totalPrice: number;
  notes?: string;
  roomNumber?: number; // For PS
}

export interface Product {
  id: string;
  name: string;
  price: number;
  discount?: number; // percentage
  imageUrl: string;
  description: string;
  shopeeUrl?: string;
  tokopediaUrl?: string;
}

export interface CartItem {
  productId: string;
  quantity: number;
}

export interface FrameTemplate {
  id: string;
  url: string;
  name: string;
}

export interface AppConfig {
  logoUrl: string;
  headerImageUrl: string;
  ownerEmail: string;
  ownerPhone: string;
  adminPin: string;
}
