
import React, { useState, useRef, useCallback } from 'react';
import { Camera, Download, RefreshCw, Layers } from 'lucide-react';
import { FrameTemplate } from '../types';

interface Props {
  templates: FrameTemplate[];
}

const PhotoboothFun: React.FC<Props> = ({ templates }) => {
  const [activeTemplate, setActiveTemplate] = useState(templates[0]);
  const [photos, setPhotos] = useState<string[]>([]);
  const [isCapturing, setIsCapturing] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsCapturing(true);
      }
    } catch (err) {
      alert("Mohon izinkan akses kamera untuk Photobooth Fun!");
    }
  };

  const takePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;
    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;

    // Set canvas to IG Story size (9:16)
    canvasRef.current.width = 1080;
    canvasRef.current.height = 1920;

    // Draw video frame to canvas
    const videoWidth = videoRef.current.videoWidth;
    const videoHeight = videoRef.current.videoHeight;
    const targetWidth = 1080;
    const targetHeight = 1920;
    
    // Fit image to portrait
    ctx.drawImage(videoRef.current, 0, 0, videoWidth, videoHeight, 0, 0, targetWidth, targetHeight);
    
    const photoData = canvasRef.current.toDataURL('image/png');
    setPhotos(prev => [...prev, photoData].slice(-3)); // Keep last 3
  };

  const downloadResult = () => {
    // Logic to combine 3 photos + frame would go here
    // For now, simple mockup
    alert("Keren! Fitur simpan ke galeri akan segera hadir. Screenshot dulu ya!");
  };

  return (
    <div className="max-w-6xl mx-auto space-y-10 animate-fadeIn">
      <div className="flex flex-col md:flex-row gap-10">
        <div className="flex-1 bg-zinc-900 rounded-[3rem] p-1 border border-zinc-800 overflow-hidden relative shadow-2xl">
          <div className="aspect-[9/16] bg-black relative">
            {!isCapturing ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center space-y-4 p-10 text-center">
                <div className="w-24 h-24 bg-easy-turquoise rounded-full flex items-center justify-center text-black mb-4">
                  <Camera size={48} />
                </div>
                <h3 className="text-2xl font-bold">Ready for Photoshoot?</h3>
                <p className="text-gray-500">Pose gokil kamu, 3x jepret dengan template eksklusif!</p>
                <button onClick={startCamera} className="bg-easy-turquoise text-black font-bold px-10 py-4 rounded-full">Buka Kamera</button>
              </div>
            ) : (
              <>
                <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover scale-x-[-1]" />
                <img src={activeTemplate.url} className="absolute inset-0 w-full h-full object-contain pointer-events-none opacity-60" alt="Frame" />
                
                <div className="absolute bottom-10 left-0 right-0 flex justify-center items-center space-x-6 px-10">
                  <button onClick={takePhoto} className="w-20 h-20 bg-white border-8 border-easy-turquoise rounded-full flex items-center justify-center text-black hover:scale-110 transition-transform shadow-xl">
                    <Camera size={32} />
                  </button>
                </div>

                <div className="absolute top-10 right-6 space-y-3">
                  {photos.map((p, i) => (
                    <div key={i} className="w-20 h-28 bg-white p-1 rounded-lg shadow-lg rotate-3 overflow-hidden">
                      <img src={p} className="w-full h-full object-cover" />
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
          <canvas ref={canvasRef} className="hidden" />
        </div>

        <div className="w-full md:w-80 space-y-6">
          <div className="bg-zinc-900 p-8 rounded-[2rem] border border-zinc-800">
            <h3 className="font-bold text-xl mb-6 flex items-center text-easy-turquoise"><Layers className="mr-2" size={20}/> Pilih Frame</h3>
            <div className="space-y-4">
              {templates.map(t => (
                <button 
                  key={t.id}
                  onClick={() => setActiveTemplate(t)}
                  className={`w-full group relative rounded-2xl overflow-hidden border-2 transition-all ${
                    activeTemplate.id === t.id ? 'border-easy-turquoise' : 'border-zinc-800'
                  }`}
                >
                  <img src={t.url} className="w-full h-24 object-cover opacity-50 group-hover:opacity-100 transition-opacity" />
                  <div className="absolute inset-0 flex items-center justify-center bg-black/40">
                    <span className="font-bold text-sm tracking-widest uppercase">{t.name}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {photos.length === 3 && (
            <div className="bg-easy-turquoise p-8 rounded-[2rem] text-black">
              <h3 className="font-black text-2xl mb-2">COMPLETE!</h3>
              <p className="font-bold opacity-80 mb-6">3 foto cakep sudah siap.</p>
              <button onClick={downloadResult} className="w-full bg-black text-white py-4 rounded-2xl font-bold flex items-center justify-center space-x-2">
                <Download size={20} />
                <span>Simpan Hasil</span>
              </button>
              <button onClick={() => setPhotos([])} className="w-full mt-3 bg-white/20 text-black py-4 rounded-2xl font-bold flex items-center justify-center space-x-2">
                <RefreshCw size={20} />
                <span>Foto Ulang</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PhotoboothFun;
