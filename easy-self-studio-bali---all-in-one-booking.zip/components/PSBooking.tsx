
import React, { useState } from 'react';
import { Gamepad2, Clock, Check, Users } from 'lucide-react';
import { Package, Booking, BusinessUnit } from '../types';

interface Props {
  packages: Package[];
  onBooking: (booking: Booking) => void;
  bookings: Booking[];
  rooms: number[];
  onClose: () => void;
}

const PSBooking: React.FC<Props> = ({ packages, onBooking, bookings, rooms, onClose }) => {
  const [selectedRoom, setSelectedRoom] = useState<number | null>(null);
  const [duration, setDuration] = useState(1);
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const pricePerHour = 15000;
  const totalPrice = duration * pricePerHour;

  const isRoomLocked = (room: number, d: string, t: string) => {
    return bookings.some(b => b.unit === BusinessUnit.PLAYSTATION && b.roomNumber === room && b.date === d && b.time === t);
  };

  const timeSlots = [];
  for (let h = 10; h <= 23; h++) {
    timeSlots.push(`${h.toString().padStart(2, '0')}:00`);
  }

  const handleBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRoom) return;
    
    const newBooking: Booking = {
      id: Math.random().toString(36).substr(2, 9),
      customerName: name,
      customerPhone: phone,
      date,
      time,
      packageId: packages[0].id,
      unit: BusinessUnit.PLAYSTATION,
      status: 'PENDING',
      totalPrice,
      roomNumber: selectedRoom
    };
    onBooking(newBooking);
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="text-center py-20 bg-zinc-900 rounded-3xl border border-zinc-800">
        <Check size={64} className="text-green-500 mx-auto mb-6" />
        <h2 className="text-3xl font-bold mb-2">Slot PS Berhasil di-Booking!</h2>
        <p className="text-gray-400 mb-8">Silakan tunjukkan bukti booking ke admin di lokasi.</p>
        <button onClick={onClose} className="bg-easy-orange px-8 py-3 rounded-full font-bold">Keren!</button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-10 animate-fadeIn">
      <div className="bg-easy-orange/20 border border-easy-orange/50 p-6 rounded-3xl flex items-center space-x-4">
         <Gamepad2 size={48} className="text-easy-orange" />
         <div>
           <h2 className="text-2xl font-bold">Easy Joy Play <span className="text-easy-orange">Rental PS4</span></h2>
           <p className="text-gray-400 text-sm">Main seru bareng temen di room private. Rp15k/jam.</p>
         </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        <div className="space-y-6">
          <div className="bg-zinc-900 p-8 rounded-3xl border border-zinc-800">
            <h3 className="text-xl font-bold mb-6 flex items-center"><span className="bg-easy-orange w-8 h-8 rounded-lg text-black flex items-center justify-center mr-3 text-sm">1</span> Pilih Room</h3>
            <div className="grid grid-cols-3 gap-4">
              {rooms.map(room => (
                <button
                  key={room}
                  onClick={() => setSelectedRoom(room)}
                  className={`p-6 rounded-2xl border-2 flex flex-col items-center justify-center transition-all ${
                    selectedRoom === room ? 'bg-easy-orange border-easy-orange text-black' : 'bg-black border-zinc-800 text-gray-400 hover:border-easy-orange/50'
                  }`}
                >
                  <span className="text-2xl font-black">R{room}</span>
                  <span className="text-[10px] uppercase font-bold tracking-widest mt-1">Ready</span>
                </button>
              ))}
            </div>
          </div>

          <div className="bg-zinc-900 p-8 rounded-3xl border border-zinc-800">
             <h3 className="text-xl font-bold mb-6 flex items-center"><span className="bg-easy-orange w-8 h-8 rounded-lg text-black flex items-center justify-center mr-3 text-sm">2</span> Durasi Main</h3>
             <div className="flex items-center space-x-4">
                <input 
                  type="range" 
                  min="1" 
                  max="8" 
                  step="1"
                  value={duration}
                  onChange={(e) => setDuration(parseInt(e.target.value))}
                  className="flex-1 accent-easy-orange"
                />
                <span className="text-2xl font-bold w-20 text-center">{duration} Jam</span>
             </div>
             <div className="mt-4 p-4 bg-black rounded-xl flex justify-between items-center">
                <span className="text-gray-400">Total Harga</span>
                <span className="text-xl font-bold text-easy-orange">Rp{totalPrice.toLocaleString()}</span>
             </div>
          </div>
        </div>

        <form onSubmit={handleBooking} className="bg-zinc-900 p-8 rounded-3xl border border-zinc-800 space-y-4">
           <h3 className="text-xl font-bold mb-4 flex items-center"><span className="bg-easy-orange w-8 h-8 rounded-lg text-black flex items-center justify-center mr-3 text-sm">3</span> Konfirmasi Waktu</h3>
           
           <div className="grid grid-cols-2 gap-4">
              <input required type="date" value={date} onChange={e => setDate(e.target.value)} className="bg-black border border-zinc-800 p-4 rounded-xl outline-none focus:border-easy-orange w-full" />
              <select required value={time} onChange={e => setTime(e.target.value)} className="bg-black border border-zinc-800 p-4 rounded-xl outline-none focus:border-easy-orange w-full">
                <option value="">Pilih Jam</option>
                {timeSlots.map(t => (
                  <option key={t} value={t} disabled={selectedRoom ? isRoomLocked(selectedRoom, date, t) : true}>{t}</option>
                ))}
              </select>
           </div>

           <div className="space-y-4 pt-4">
              <input required placeholder="Nama Lengkap" value={name} onChange={e => setName(e.target.value)} className="bg-black border border-zinc-800 p-4 rounded-xl w-full outline-none focus:border-easy-orange" />
              <input required placeholder="WhatsApp (08...)" value={phone} onChange={e => setPhone(e.target.value)} className="bg-black border border-zinc-800 p-4 rounded-xl w-full outline-none focus:border-easy-orange" />
           </div>

           <button 
             disabled={!selectedRoom || !date || !time}
             className="w-full py-4 bg-easy-orange text-black font-extrabold rounded-2xl mt-6 disabled:opacity-50 hover:scale-[1.02] transition-transform"
           >
             GAS MAIN!
           </button>
        </form>
      </div>
    </div>
  );
};

export default PSBooking;
