
import React, { useState } from 'react';
import { ShoppingBag, ArrowUpRight, X, ShoppingCart, Minus, Plus, ExternalLink, MessageCircle } from 'lucide-react';
import { Product, AppConfig, CartItem } from '../types';

interface Props {
  products: Product[];
  config: AppConfig;
}

const AnallsStore: React.FC<Props> = ({ products, config }) => {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  const addToCart = (productId: string) => {
    setCart(prev => {
      const existing = prev.find(item => item.productId === productId);
      if (existing) {
        return prev.map(item => item.productId === productId ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { productId, quantity: 1 }];
    });
  };

  const updateQuantity = (productId: string, delta: number) => {
    setCart(prev => {
      return prev.map(item => {
        if (item.productId === productId) {
          const newQty = Math.max(0, item.quantity + delta);
          return { ...item, quantity: newQty };
        }
        return item;
      }).filter(item => item.quantity > 0);
    });
  };

  const calculateFinalPrice = (price: number, discount?: number) => {
    if (!discount) return price;
    return price - (price * discount / 100);
  };

  const totalCartItems = cart.reduce((acc, item) => acc + item.quantity, 0);

  const handleCheckoutWA = () => {
    let message = "Halo Analls Store! Saya ingin memesan:\n\n";
    cart.forEach(item => {
      const product = products.find(p => p.id === item.productId);
      if (product) {
        const finalPrice = calculateFinalPrice(product.price, product.discount);
        message += `- ${product.name} x${item.quantity} (Rp${(finalPrice * item.quantity).toLocaleString()})\n`;
      }
    });
    const total = cart.reduce((acc, item) => {
      const product = products.find(p => p.id === item.productId);
      return acc + (calculateFinalPrice(product?.price || 0, product?.discount) * item.quantity);
    }, 0);
    message += `\nTotal: Rp${total.toLocaleString()}`;
    window.open(`https://wa.me/${config.ownerPhone}?text=${encodeURIComponent(message)}`, '_blank');
  };

  return (
    <div className="max-w-6xl mx-auto space-y-12 animate-fadeIn relative">
      {/* Header */}
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-5xl font-black tracking-tighter italic">ANALLS <span className="text-easy-yellow">STORE</span></h1>
          <p className="text-gray-500 mt-2 font-medium">Original merchandise & local goods.</p>
        </div>
        <button 
          onClick={() => setIsCartOpen(true)}
          className="relative bg-zinc-900 border border-zinc-800 p-4 rounded-2xl flex items-center space-x-3 hover:border-easy-yellow transition-all group"
        >
          <ShoppingCart size={24} className="group-hover:text-easy-yellow transition-colors" />
          <span className="font-bold">Cart</span>
          {totalCartItems > 0 && (
            <span className="absolute -top-2 -right-2 bg-easy-yellow text-black w-6 h-6 rounded-full text-[10px] font-black flex items-center justify-center border-2 border-black">
              {totalCartItems}
            </span>
          )}
        </button>
      </div>

      {/* Product Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {products.map(p => (
          <div key={p.id} className="group cursor-pointer" onClick={() => setSelectedProduct(p)}>
            <div className="relative aspect-square rounded-3xl overflow-hidden bg-zinc-900 mb-4">
              <img src={p.imageUrl} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
              {p.discount && (
                <div className="absolute top-4 left-4 bg-red-600 text-white text-[10px] font-black px-3 py-1 rounded-full">
                  -{p.discount}% OFF
                </div>
              )}
              <div className="absolute top-4 right-4 bg-black/60 backdrop-blur-md p-2 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity">
                <ArrowUpRight size={20} className="text-easy-yellow" />
              </div>
            </div>
            <h3 className="font-bold text-lg truncate">{p.name}</h3>
            <div className="flex items-center space-x-2">
              <p className="text-easy-yellow font-black">
                Rp{calculateFinalPrice(p.price, p.discount).toLocaleString()}
              </p>
              {p.discount && (
                <p className="text-gray-500 line-through text-xs font-medium">
                  Rp{p.price.toLocaleString()}
                </p>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Collaboration Banner */}
      <div className="bg-zinc-900 rounded-[3rem] p-16 text-center border border-zinc-800">
        <h2 className="text-3xl font-bold mb-4">Ingin Menitipkan Produk?</h2>
        <p className="text-gray-400 mb-8 max-w-md mx-auto">Kami membuka kolaborasi bagi brand lokal Bali yang ingin display produk di Analls Store.</p>
        <button 
           onClick={() => window.open(`https://wa.me/${config.ownerPhone}?text=Halo! Saya tertarik titip jual produk di Analls Store`, '_blank')}
           className="bg-white text-black font-black px-10 py-4 rounded-full hover:scale-105 transition-transform"
        >
          HUBUNGI KAMI
        </button>
      </div>

      {/* Product Detail Modal */}
      {selectedProduct && (
        <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-zinc-800 w-full max-w-4xl rounded-[3rem] overflow-hidden relative animate-zoomIn flex flex-col md:flex-row shadow-2xl">
            <button onClick={() => setSelectedProduct(null)} className="absolute top-6 right-6 z-10 text-gray-400 hover:text-white bg-black/50 p-2 rounded-full backdrop-blur-md">
              <X size={24}/>
            </button>
            
            <div className="w-full md:w-1/2 aspect-square bg-black">
              <img src={selectedProduct.imageUrl} className="w-full h-full object-cover" />
            </div>
            
            <div className="w-full md:w-1/2 p-10 flex flex-col h-full">
              <div className="mb-2 text-easy-yellow font-bold text-xs uppercase tracking-widest">Detail Produk</div>
              <h2 className="text-3xl font-black mb-4">{selectedProduct.name}</h2>
              
              <div className="flex items-baseline space-x-3 mb-6">
                <span className="text-3xl font-black text-white">
                  Rp{calculateFinalPrice(selectedProduct.price, selectedProduct.discount).toLocaleString()}
                </span>
                {selectedProduct.discount && (
                  <>
                    <span className="text-gray-500 line-through">Rp{selectedProduct.price.toLocaleString()}</span>
                    <span className="bg-red-500/20 text-red-500 px-2 py-0.5 rounded text-[10px] font-black">SAVE {selectedProduct.discount}%</span>
                  </>
                )}
              </div>
              
              <p className="text-gray-400 mb-8 text-sm leading-relaxed flex-1">
                {selectedProduct.description || "No description provided."}
              </p>

              <div className="space-y-4">
                <button 
                  onClick={() => { addToCart(selectedProduct.id); setSelectedProduct(null); }}
                  className="w-full bg-easy-yellow text-black font-black py-4 rounded-2xl flex items-center justify-center space-x-2 hover:scale-[1.02] transition-transform"
                >
                  <ShoppingCart size={20} />
                  <span>Masukan Keranjang</span>
                </button>
                
                <div className="flex gap-4">
                  {selectedProduct.shopeeUrl && (
                    <a href={selectedProduct.shopeeUrl} target="_blank" className="flex-1 bg-orange-500/10 border border-orange-500/50 text-orange-500 py-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 hover:bg-orange-500 hover:text-white transition-all">
                       <ExternalLink size={14} /> <span>Shopee</span>
                    </a>
                  )}
                  {selectedProduct.tokopediaUrl && (
                    <a href={selectedProduct.tokopediaUrl} target="_blank" className="flex-1 bg-green-500/10 border border-green-500/50 text-green-500 py-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 hover:bg-green-500 hover:text-white transition-all">
                       <ExternalLink size={14} /> <span>Tokopedia</span>
                    </a>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Cart Sidebar */}
      {isCartOpen && (
        <div className="fixed inset-0 z-[110] flex justify-end">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setIsCartOpen(false)} />
          <div className="relative w-full max-w-md bg-zinc-950 h-full shadow-2xl flex flex-col animate-slideInRight">
             <div className="p-8 border-b border-zinc-800 flex justify-between items-center">
               <h3 className="text-2xl font-black flex items-center">
                 <ShoppingCart size={24} className="mr-3 text-easy-yellow"/> Keranjang
               </h3>
               <button onClick={() => setIsCartOpen(false)} className="text-gray-500 hover:text-white"><X size={28}/></button>
             </div>
             
             <div className="flex-1 overflow-y-auto p-8 space-y-6">
               {cart.length === 0 ? (
                 <div className="h-full flex flex-col items-center justify-center text-center space-y-4">
                   <div className="w-20 h-20 bg-zinc-900 rounded-full flex items-center justify-center text-zinc-700">
                     <ShoppingBag size={40} />
                   </div>
                   <p className="text-gray-500 font-bold">Keranjang kosong.</p>
                 </div>
               ) : (
                 cart.map(item => {
                   const product = products.find(p => p.id === item.productId);
                   if (!product) return null;
                   const finalPrice = calculateFinalPrice(product.price, product.discount);
                   return (
                     <div key={item.productId} className="flex space-x-4 group">
                       <div className="w-20 h-20 bg-zinc-900 rounded-2xl overflow-hidden shrink-0">
                         <img src={product.imageUrl} className="w-full h-full object-cover" />
                       </div>
                       <div className="flex-1">
                         <div className="font-bold text-sm mb-1">{product.name}</div>
                         <div className="text-easy-yellow font-black text-xs mb-3">Rp{finalPrice.toLocaleString()}</div>
                         <div className="flex items-center space-x-4">
                           <button onClick={() => updateQuantity(item.productId, -1)} className="w-8 h-8 rounded-lg bg-zinc-900 flex items-center justify-center hover:bg-zinc-800"><Minus size={14}/></button>
                           <span className="font-black text-sm">{item.quantity}</span>
                           <button onClick={() => updateQuantity(item.productId, 1)} className="w-8 h-8 rounded-lg bg-zinc-900 flex items-center justify-center hover:bg-zinc-800"><Plus size={14}/></button>
                         </div>
                       </div>
                     </div>
                   );
                 })
               )}
             </div>
             
             {cart.length > 0 && (
               <div className="p-8 bg-zinc-900/50 border-t border-zinc-800 space-y-4">
                 <div className="flex justify-between items-center mb-4">
                   <span className="text-gray-400 font-bold">Total Pembayaran</span>
                   <span className="text-2xl font-black text-easy-yellow">
                     Rp{cart.reduce((acc, item) => {
                       const product = products.find(p => p.id === item.productId);
                       return acc + (calculateFinalPrice(product?.price || 0, product?.discount) * item.quantity);
                     }, 0).toLocaleString()}
                   </span>
                 </div>
                 <button 
                   onClick={handleCheckoutWA}
                   className="w-full bg-green-600 text-white font-black py-4 rounded-2xl flex items-center justify-center space-x-3 hover:bg-green-700 transition-colors shadow-lg"
                 >
                   <MessageCircle size={20} />
                   <span>Checkout via WhatsApp</span>
                 </button>
               </div>
             )}
          </div>
        </div>
      )}
    </div>
  );
};

export default AnallsStore;
