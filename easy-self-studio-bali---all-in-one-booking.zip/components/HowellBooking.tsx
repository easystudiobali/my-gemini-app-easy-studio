
import React, { useState } from 'react';
import { ImageIcon, Printer, Check, Info } from 'lucide-react';
import { Package, Booking, BusinessUnit } from '../types';

interface Props {
  packages: Package[];
  onBooking: (booking: Booking) => void;
  bookings: Booking[];
  onClose: () => void;
}

const HowellBooking: React.FC<Props> = ({ packages, onBooking, bookings, onClose }) => {
  const [selectedPkg, setSelectedPkg] = useState<Package | null>(null);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPkg) return;
    
    const formData = new FormData(e.currentTarget as HTMLFormElement);
    const newBooking: Booking = {
      id: Math.random().toString(36).substr(2, 9),
      customerName: formData.get('name') as string,
      customerPhone: formData.get('phone') as string,
      date: formData.get('date') as string,
      time: '09:00', // Default full day
      packageId: selectedPkg.id,
      unit: BusinessUnit.HOWELL,
      status: 'PENDING',
      totalPrice: selectedPkg.price
    };
    onBooking(newBooking);
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="text-center py-20 bg-zinc-900 rounded-3xl border border-zinc-800">
        <Check size={64} className="text-easy-turquoise mx-auto mb-6" />
        <h2 className="text-3xl font-bold mb-2">Permintaan Sewa Terkirim!</h2>
        <p className="text-gray-400 mb-8">Tim Howell akan segera menghubungi Anda untuk koordinasi pengiriman.</p>
        <button onClick={onClose} className="bg-easy-turquoise text-black px-8 py-3 rounded-full font-bold">Oke!</button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-10 animate-fadeIn">
      <div className="text-center">
        <h1 className="text-4xl font-extrabold text-easy-turquoise mb-4 uppercase tracking-tighter italic">Howell <span className="text-white not-italic">Rental</span></h1>
        <p className="text-gray-400 max-w-lg mx-auto">Solusi dokumentasi instan untuk event Anda di Bali.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {packages.map(pkg => (
          <div 
            key={pkg.id} 
            className={`bg-zinc-900 rounded-[2.5rem] border-2 p-8 transition-all ${
              selectedPkg?.id === pkg.id ? 'border-easy-turquoise shadow-[0_0_30px_rgba(45,212,191,0.2)]' : 'border-zinc-800'
            }`}
          >
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-6 ${pkg.id.includes('hw-1') ? 'bg-easy-turquoise' : 'bg-zinc-800'}`}>
              {pkg.id.includes('hw-1') ? <ImageIcon size={32} className="text-black" /> : <Printer size={32} className="text-white" />}
            </div>
            <h3 className="text-2xl font-bold mb-2">{pkg.name}</h3>
            <p className="text-gray-400 text-sm mb-6 min-h-[40px]">{pkg.description}</p>
            <div className="text-3xl font-black text-easy-turquoise mb-8">Rp{pkg.price.toLocaleString()}</div>
            
            <button 
              onClick={() => setSelectedPkg(pkg)}
              className={`w-full py-4 rounded-2xl font-bold transition-all ${
                selectedPkg?.id === pkg.id ? 'bg-easy-turquoise text-black' : 'bg-zinc-800 text-white hover:bg-zinc-700'
              }`}
            >
              {selectedPkg?.id === pkg.id ? 'Terpilih' : 'Pilih Paket'}
            </button>
          </div>
        ))}
      </div>

      {selectedPkg && (
        <form onSubmit={handleSubmit} className="bg-zinc-900 rounded-[2.5rem] p-10 border border-zinc-800 space-y-8 animate-fadeIn">
           <div className="flex items-center space-x-3 text-easy-turquoise font-bold uppercase tracking-widest text-sm">
             <Info size={18} />
             <span>Informasi Penyewa</span>
           </div>
           <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-500">NAMA LENGKAP</label>
                <input required name="name" className="w-full bg-black border border-zinc-800 p-4 rounded-xl focus:border-easy-turquoise outline-none" />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-500">WHATSAPP</label>
                <input required name="phone" className="w-full bg-black border border-zinc-800 p-4 rounded-xl focus:border-easy-turquoise outline-none" />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-500">TANGGAL EVENT</label>
                <input required name="date" type="date" className="w-full bg-black border border-zinc-800 p-4 rounded-xl focus:border-easy-turquoise outline-none" />
              </div>
           </div>
           <button className="w-full bg-easy-turquoise text-black font-black text-xl py-6 rounded-3xl shadow-lg hover:translate-y-[-2px] transition-transform">
             KONFIRMASI PENYEWAAN
           </button>
        </form>
      )}
    </div>
  );
};

export default HowellBooking;
