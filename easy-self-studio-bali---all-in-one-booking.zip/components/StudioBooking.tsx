
import React, { useState } from 'react';
import { Calendar, Clock, User, Phone, Check, ArrowRight } from 'lucide-react';
import { Package, Booking, BusinessUnit, AppConfig } from '../types';

interface Props {
  packages: Package[];
  onBooking: (booking: Booking) => void;
  bookings: Booking[];
  config: AppConfig;
  onClose: () => void;
}

const StudioBooking: React.FC<Props> = ({ packages, onBooking, bookings, config, onClose }) => {
  const [step, setStep] = useState(1);
  const [selectedPkg, setSelectedPkg] = useState<Package | null>(null);
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');

  // Business logic: 10:00 - 21:00, 30 min intervals
  const timeSlots = [];
  for (let h = 10; h <= 21; h++) {
    timeSlots.push(`${h.toString().padStart(2, '0')}:00`);
    timeSlots.push(`${h.toString().padStart(2, '0')}:30`);
  }

  const isTimeLocked = (d: string, t: string) => {
    return bookings.some(b => b.date === d && b.time === t && b.unit === BusinessUnit.PHOTO_STUDIO);
  };

  const handleNext = () => {
    if (step === 1 && selectedPkg) setStep(2);
    else if (step === 2 && date && time) setStep(3);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPkg) return;

    const newBooking: Booking = {
      id: Math.random().toString(36).substr(2, 9),
      customerName: name,
      customerPhone: phone,
      date,
      time,
      packageId: selectedPkg.id,
      unit: BusinessUnit.PHOTO_STUDIO,
      status: 'PENDING',
      totalPrice: selectedPkg.price
    };
    onBooking(newBooking);
    setStep(4);
  };

  return (
    <div className="max-w-4xl mx-auto animate-fadeIn">
      <div className="flex justify-between items-center mb-10">
        <h2 className="text-3xl font-extrabold">Studio <span className="text-easy-yellow">Photo Booking</span></h2>
        <div className="flex items-center space-x-2">
          {[1, 2, 3].map(s => (
            <div key={s} className={`h-2 w-8 rounded-full ${step >= s ? 'bg-easy-yellow' : 'bg-zinc-800'}`} />
          ))}
        </div>
      </div>

      {step === 1 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {packages.map(pkg => (
            <button
              key={pkg.id}
              onClick={() => setSelectedPkg(pkg)}
              className={`p-6 rounded-3xl border-2 text-left transition-all relative group ${
                selectedPkg?.id === pkg.id ? 'border-easy-yellow bg-easy-yellow/10' : 'border-zinc-800 bg-zinc-900/50 hover:border-zinc-700'
              }`}
            >
              <div className="flex justify-between items-start mb-4">
                <h3 className="font-bold text-xl">{pkg.name}</h3>
                <span className="text-easy-yellow font-bold text-lg">Rp{(pkg.price/1000)}k</span>
              </div>
              <p className="text-gray-400 text-sm mb-4">{pkg.description}</p>
              <div className="flex items-center space-x-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                <span className="flex items-center"><User size={14} className="mr-1"/> Max {pkg.maxPeople}</span>
                <span className="flex items-center"><Clock size={14} className="mr-1"/> {pkg.duration}m</span>
              </div>
              {selectedPkg?.id === pkg.id && (
                <div className="absolute -top-3 -right-3 bg-easy-yellow text-black rounded-full p-1"><Check size={20} /></div>
              )}
            </button>
          ))}
          <button 
            disabled={!selectedPkg}
            onClick={handleNext}
            className="md:col-span-2 mt-6 w-full py-4 bg-easy-yellow text-black font-extrabold rounded-2xl disabled:opacity-50 flex items-center justify-center space-x-2 group"
          >
            <span>Lanjutkan Pilih Waktu</span> <ArrowRight className="group-hover:translate-x-2 transition-transform" />
          </button>
        </div>
      )}

      {step === 2 && (
        <div className="bg-zinc-900 rounded-3xl p-8 border border-zinc-800">
          <div className="mb-8">
            <label className="block text-sm font-bold text-gray-400 mb-2 uppercase tracking-widest">Pilih Tanggal</label>
            <input 
              type="date" 
              className="w-full bg-black border border-zinc-800 rounded-2xl p-4 focus:border-easy-yellow outline-none text-xl"
              min={new Date().toISOString().split('T')[0]}
              value={date}
              onChange={(e) => setDate(e.target.value)}
            />
          </div>

          <div>
            <label className="block text-sm font-bold text-gray-400 mb-2 uppercase tracking-widest">Pilih Jam (Sudah Di-lock di Kalender)</label>
            <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
              {timeSlots.map(t => {
                const locked = isTimeLocked(date, t);
                return (
                  <button
                    key={t}
                    disabled={locked || !date}
                    onClick={() => setTime(t)}
                    className={`py-3 rounded-xl border text-sm font-bold transition-all ${
                      locked ? 'bg-zinc-800 border-transparent text-gray-600 cursor-not-allowed line-through' :
                      time === t ? 'bg-easy-yellow border-easy-yellow text-black' : 'bg-black border-zinc-800 text-white hover:border-zinc-500'
                    }`}
                  >
                    {t}
                  </button>
                );
              })}
            </div>
          </div>

          <button 
            disabled={!time}
            onClick={handleNext}
            className="mt-10 w-full py-4 bg-easy-yellow text-black font-extrabold rounded-2xl disabled:opacity-50"
          >
            Lanjutkan Data Diri
          </button>
        </div>
      )}

      {step === 3 && (
        <form onSubmit={handleSubmit} className="bg-zinc-900 rounded-3xl p-8 border border-zinc-800 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-bold text-gray-400 mb-2 uppercase tracking-widest">Nama Lengkap</label>
              <input required value={name} onChange={e => setName(e.target.value)} className="w-full bg-black border border-zinc-800 rounded-2xl p-4 focus:border-easy-yellow outline-none" />
            </div>
            <div>
              <label className="block text-sm font-bold text-gray-400 mb-2 uppercase tracking-widest">WhatsApp</label>
              <input required value={phone} onChange={e => setPhone(e.target.value)} placeholder="08..." className="w-full bg-black border border-zinc-800 rounded-2xl p-4 focus:border-easy-yellow outline-none" />
            </div>
          </div>
          
          <div className="p-6 bg-zinc-800 rounded-2xl space-y-3">
             <div className="flex justify-between"><span>Paket</span><span className="font-bold">{selectedPkg?.name}</span></div>
             <div className="flex justify-between"><span>Jadwal</span><span className="font-bold">{date} @ {time}</span></div>
             <div className="h-px bg-zinc-700 my-2" />
             <div className="flex justify-between text-easy-yellow font-bold text-xl"><span>Total</span><span>Rp{selectedPkg?.price.toLocaleString()}</span></div>
          </div>

          <button type="submit" className="w-full py-4 bg-easy-yellow text-black font-extrabold rounded-2xl">
            Booking Sekarang (Lock Calendar)
          </button>
        </form>
      )}

      {step === 4 && (
        <div className="text-center bg-zinc-900 rounded-3xl p-12 border border-zinc-800 animate-zoomIn">
          <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6 text-black">
            <Check size={48} />
          </div>
          <h2 className="text-3xl font-bold mb-4">Booking Berhasil!</h2>
          <p className="text-gray-400 mb-8 max-w-sm mx-auto">Data Anda telah tercatat di Google Sheet & Google Calendar kami. Sampai jumpa di Easy Self Studio Bali!</p>
          <button onClick={onClose} className="px-10 py-4 bg-easy-yellow text-black font-extrabold rounded-full">Selesai</button>
        </div>
      )}
    </div>
  );
};

export default StudioBooking;
