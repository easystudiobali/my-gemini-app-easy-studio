
import { Package, BusinessUnit, AppConfig, Product } from './types';

export const INITIAL_PACKAGES: Package[] = [
  { id: '1', name: 'Single', price: 60000, maxPeople: 1, duration: 20, description: '1 free print 4R & all soft copies', unit: BusinessUnit.PHOTO_STUDIO },
  { id: '2', name: 'Couple', price: 90000, maxPeople: 2, duration: 20, description: '1 free print 4R & all soft copies', unit: BusinessUnit.PHOTO_STUDIO },
  { id: '3', name: 'Thirdwell', price: 110000, maxPeople: 3, duration: 20, description: '1 free print 4R & all soft copies', unit: BusinessUnit.PHOTO_STUDIO },
  { id: '4', name: 'Family', price: 135000, maxPeople: 4, duration: 20, description: '1 free print 4R & all soft copies', unit: BusinessUnit.PHOTO_STUDIO },
  { id: '5', name: 'Hourly', price: 250000, maxPeople: 5, duration: 60, description: '2 free print 4R', unit: BusinessUnit.PHOTO_STUDIO },
  { id: '6', name: 'Pets Portrait', price: 80000, maxPeople: 2, duration: 20, description: 'Bring your pets!', unit: BusinessUnit.PHOTO_STUDIO },
  // PS
  { id: 'ps-1', name: 'PlayStation 4 - 1 Hour', price: 15000, maxPeople: 2, duration: 60, description: 'Private room PS4 rental', unit: BusinessUnit.PLAYSTATION },
  // Howell
  { id: 'hw-1', name: 'Photobooth Rental', price: 1500000, maxPeople: 100, duration: 240, description: 'Full photobooth setup', unit: BusinessUnit.HOWELL },
  { id: 'hw-2', name: 'DNP Printer Only', price: 375000, maxPeople: 0, duration: 1440, description: 'High speed photo printer rental (1 day)', unit: BusinessUnit.HOWELL },
];

export const INITIAL_PRODUCTS: Product[] = [
  { 
    id: 'p1', 
    name: 'Easy Tee Vol.1', 
    price: 150000, 
    discount: 10, 
    imageUrl: 'https://picsum.photos/400/400?random=10',
    description: 'Cotton combed 24s. Oversized fit. Screen printed graphics.',
    shopeeUrl: 'https://shopee.co.id',
    tokopediaUrl: 'https://tokopedia.com'
  },
  { 
    id: 'p2', 
    name: 'Analls Sticker Pack', 
    price: 25000, 
    imageUrl: 'https://picsum.photos/400/400?random=11',
    description: 'Vibrant vinyl stickers. Waterproof and sun-resistant.',
    shopeeUrl: 'https://shopee.co.id'
  }
];

export const INITIAL_CONFIG: AppConfig = {
  logoUrl: 'https://picsum.photos/200/200?random=1',
  headerImageUrl: 'https://picsum.photos/1200/400?grayscale',
  ownerEmail: 'easyselfstudio@gmail.com',
  ownerPhone: '6285157593775',
  adminPin: '1234'
};

export const PS_ROOMS = [1, 2, 3];
