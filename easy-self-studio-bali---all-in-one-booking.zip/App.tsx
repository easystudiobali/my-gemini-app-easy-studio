
import React, { useState, useEffect } from 'react';
import { 
  Camera, 
  Gamepad2, 
  ShoppingBag, 
  Image as ImageIcon, 
  Settings, 
  Calendar, 
  Clock, 
  Phone, 
  X, 
  CheckCircle2, 
  ArrowRight,
  Menu,
  ChevronRight,
  Plus
} from 'lucide-react';
import { BusinessUnit, Package, Booking, AppConfig, FrameTemplate, Product } from './types';
import { INITIAL_PACKAGES, INITIAL_CONFIG, PS_ROOMS, INITIAL_PRODUCTS } from './constants';
import StudioBooking from './components/StudioBooking';
import PSBooking from './components/PSBooking';
import HowellBooking from './components/HowellBooking';
import AnallsStore from './components/AnallsStore';
import PhotoboothFun from './components/PhotoboothFun';
import AdminPanel from './components/AdminPanel';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<BusinessUnit | 'FUN' | 'ADMIN' | 'HOME'>('HOME');
  const [packages, setPackages] = useState<Package[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [config, setConfig] = useState<AppConfig>(INITIAL_CONFIG);
  const [templates, setTemplates] = useState<FrameTemplate[]>([
    { id: 't1', name: 'Easy Vibe', url: 'https://picsum.photos/400/600?random=2' },
    { id: 't2', name: 'Bali Sunset', url: 'https://picsum.photos/400/600?random=3' }
  ]);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const savedPackages = localStorage.getItem('easy_packages');
    const savedProducts = localStorage.getItem('easy_products');
    const savedBookings = localStorage.getItem('easy_bookings');
    const savedConfig = localStorage.getItem('easy_config');
    const savedTemplates = localStorage.getItem('easy_templates');

    if (savedPackages) setPackages(JSON.parse(savedPackages));
    else setPackages(INITIAL_PACKAGES);

    if (savedProducts) setProducts(JSON.parse(savedProducts));
    else setProducts(INITIAL_PRODUCTS);

    if (savedBookings) setBookings(JSON.parse(savedBookings));
    
    if (savedConfig) setConfig(JSON.parse(savedConfig));

    if (savedTemplates) setTemplates(JSON.parse(savedTemplates));
  }, []);

  useEffect(() => {
    if (packages.length > 0) localStorage.setItem('easy_packages', JSON.stringify(packages));
    if (products.length > 0) localStorage.setItem('easy_products', JSON.stringify(products));
    localStorage.setItem('easy_bookings', JSON.stringify(bookings));
    localStorage.setItem('easy_config', JSON.stringify(config));
    localStorage.setItem('easy_templates', JSON.stringify(templates));
  }, [packages, products, bookings, config, templates]);

  const handleBookingSubmit = (newBooking: Booking) => {
    setBookings(prev => [...prev, newBooking]);
    const pkg = packages.find(p => p.id === newBooking.packageId);
    const text = `Halo Easy Self Studio!\n\nBooking Baru!\nUnit: ${newBooking.unit}\nCustomer: ${newBooking.customerName}\nPhone: ${newBooking.customerPhone}\nPaket: ${pkg?.name}\nTanggal: ${newBooking.date}\nJam: ${newBooking.time}\nTotal: Rp${newBooking.totalPrice.toLocaleString()}\n\nMohon konfirmasi booking ini.`;
    window.open(`https://wa.me/${config.ownerPhone}?text=${encodeURIComponent(text)}`, '_blank');
  };

  const navigateHome = () => setActiveTab('HOME');

  const renderContent = () => {
    switch (activeTab) {
      case 'HOME':
        return (
          <div className="space-y-8 animate-fadeIn">
            <div className="relative h-64 rounded-3xl overflow-hidden mb-10 group">
              <img src={config.headerImageUrl} alt="Hero" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent flex flex-col justify-end p-8">
                <h1 className="text-4xl font-extrabold text-white mb-2 tracking-tight">Easy Self Studio Bali</h1>
                <p className="text-gray-200 font-medium">Capture your best moments, play your favorite games.</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { id: BusinessUnit.PHOTO_STUDIO, title: 'Self Studio', icon: Camera, color: 'bg-easy-yellow', text: 'Capture moments' },
                { id: BusinessUnit.PLAYSTATION, title: 'Easy Joy Play', icon: Gamepad2, color: 'bg-easy-orange', text: 'Gaming lounge' },
                { id: BusinessUnit.HOWELL, title: 'Howell', icon: ImageIcon, color: 'bg-easy-turquoise', text: 'Photobooth rental' },
                { id: BusinessUnit.ANALLS, title: 'Analls', icon: ShoppingBag, color: 'bg-zinc-800', text: 'Retail Shop' }
              ].map((item) => (
                <button 
                  key={item.id}
                  onClick={() => setActiveTab(item.id as BusinessUnit)}
                  className={`${item.color} p-8 rounded-3xl flex flex-col items-center justify-center space-y-4 hover:scale-105 transition-all shadow-lg hover:shadow-2xl text-black`}
                >
                  <item.icon size={48} className={item.id === BusinessUnit.ANALLS ? 'text-white' : 'text-black'} />
                  <div className="text-center">
                    <h3 className={`font-bold text-xl ${item.id === BusinessUnit.ANALLS ? 'text-white' : 'text-black'}`}>{item.title}</h3>
                    <p className={`text-sm opacity-80 ${item.id === BusinessUnit.ANALLS ? 'text-gray-400' : 'text-black'}`}>{item.text}</p>
                  </div>
                </button>
              ))}
            </div>

            <div className="mt-12 bg-zinc-900 border border-zinc-800 rounded-3xl p-8 flex items-center justify-between group cursor-pointer" onClick={() => setActiveTab('FUN')}>
              <div>
                <h2 className="text-2xl font-bold text-easy-yellow">Virtual Photobooth FUN!</h2>
                <p className="text-gray-400">Try our live filters and frames before you visit.</p>
              </div>
              <div className="bg-easy-yellow p-4 rounded-full text-black group-hover:rotate-12 transition-transform">
                <ImageIcon size={32} />
              </div>
            </div>
          </div>
        );
      case BusinessUnit.PHOTO_STUDIO:
        return <StudioBooking packages={packages.filter(p => p.unit === BusinessUnit.PHOTO_STUDIO)} onBooking={handleBookingSubmit} bookings={bookings} config={config} onClose={navigateHome} />;
      case BusinessUnit.PLAYSTATION:
        return <PSBooking packages={packages.filter(p => p.unit === BusinessUnit.PLAYSTATION)} onBooking={handleBookingSubmit} bookings={bookings} rooms={PS_ROOMS} onClose={navigateHome} />;
      case BusinessUnit.HOWELL:
        return <HowellBooking packages={packages.filter(p => p.unit === BusinessUnit.HOWELL)} onBooking={handleBookingSubmit} bookings={bookings} onClose={navigateHome} />;
      case BusinessUnit.ANALLS:
        return <AnallsStore products={products} config={config} />;
      case 'FUN':
        return <PhotoboothFun templates={templates} />;
      case 'ADMIN':
        return (
          <AdminPanel 
            packages={packages} 
            setPackages={setPackages} 
            products={products}
            setProducts={setProducts}
            bookings={bookings} 
            setBookings={setBookings} 
            config={config} 
            setConfig={setConfig} 
            templates={templates}
            setTemplates={setTemplates}
          />
        );
      default:
        return <div>Not found</div>;
    }
  };

  return (
    <div className="min-h-screen bg-black text-white">
      <nav className="sticky top-0 z-50 bg-black/80 backdrop-blur-md border-b border-zinc-800">
        <div className="max-w-7xl mx-auto px-4 h-20 flex items-center justify-between">
          <div className="flex items-center space-x-4 cursor-pointer" onClick={() => setActiveTab('HOME')}>
            <div className="w-12 h-12 bg-easy-yellow rounded-xl flex items-center justify-center overflow-hidden">
               <img src={config.logoUrl} alt="Logo" className="w-full h-full object-cover" />
            </div>
            <div>
              <span className="font-extrabold text-xl tracking-tight block">EASY SELF STUDIO</span>
              <span className="text-[10px] uppercase font-bold text-easy-orange tracking-widest">BALI - EST 2024</span>
            </div>
          </div>

          <div className="hidden lg:flex items-center space-x-1 font-semibold">
            {['HOME', BusinessUnit.PHOTO_STUDIO, BusinessUnit.PLAYSTATION, BusinessUnit.HOWELL, BusinessUnit.ANALLS, 'FUN'].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab as any)}
                className={`px-6 py-2 rounded-full transition-all ${
                  activeTab === tab ? 'bg-zinc-800 text-easy-yellow' : 'text-gray-400 hover:text-white hover:bg-zinc-900'
                }`}
              >
                {tab === BusinessUnit.PHOTO_STUDIO ? 'Studio' : 
                 tab === BusinessUnit.PLAYSTATION ? 'Gaming' : 
                 tab === BusinessUnit.HOWELL ? 'Howell' : 
                 tab === BusinessUnit.ANALLS ? 'Retail' : tab}
              </button>
            ))}
            <button 
              onClick={() => setActiveTab('ADMIN')}
              className={`p-2 rounded-full ${activeTab === 'ADMIN' ? 'text-easy-orange' : 'text-gray-400 hover:text-white'}`}
            >
              <Settings size={22} />
            </button>
          </div>

          <button className="lg:hidden p-2 text-gray-400" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            <Menu size={28} />
          </button>
        </div>
      </nav>

      {isMenuOpen && (
        <div className="fixed inset-0 z-[60] bg-black p-6 space-y-6">
          <div className="flex justify-between items-center mb-8">
            <span className="text-2xl font-bold">Menu</span>
            <button onClick={() => setIsMenuOpen(false)}><X size={32} /></button>
          </div>
          {['HOME', BusinessUnit.PHOTO_STUDIO, BusinessUnit.PLAYSTATION, BusinessUnit.HOWELL, BusinessUnit.ANALLS, 'FUN', 'ADMIN'].map((tab) => (
            <button
              key={tab}
              onClick={() => { setActiveTab(tab as any); setIsMenuOpen(false); }}
              className="w-full text-left py-4 border-b border-zinc-800 text-2xl font-bold flex justify-between items-center"
            >
              {tab} <ChevronRight />
            </button>
          ))}
        </div>
      )}

      <main className="max-w-7xl mx-auto px-4 py-10 pb-32">
        {renderContent()}
      </main>

      {activeTab === 'HOME' && (
        <div className="fixed bottom-8 left-1/2 -translate-x-1/2 bg-zinc-900 border border-zinc-800 p-4 rounded-full shadow-2xl flex items-center space-x-4 z-40 backdrop-blur-xl">
           <a href={`https://wa.me/${config.ownerPhone}`} target="_blank" className="flex items-center space-x-3 bg-green-500 hover:bg-green-600 transition-colors px-6 py-3 rounded-full font-bold text-white">
             <Phone size={20} />
             <span>Tanya Owner</span>
           </a>
        </div>
      )}
    </div>
  );
};

export default App;
